const apiRoutes = require('./api')
const webRoutes = require('./web')

module.exports = {
  apiRoutes,
  webRoutes
}