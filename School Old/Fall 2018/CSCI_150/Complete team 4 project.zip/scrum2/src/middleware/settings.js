
module.exports = {
    'secret':'mevnsecure'
  };