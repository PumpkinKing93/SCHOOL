const { errorHandlers } = require('./error-handler')

module.exports = {
  errorHandlers
}