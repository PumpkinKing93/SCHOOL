#pragma once
class Shop
{
public:
	Shop();
	~Shop();
};

