//
//  car.cpp
//  144 Project
//
//  Created by Tyler Gillette on 11/11/19.
//  Copyright © 2019 Tyler  Gillette. All rights reserved.
//

#include "car.hpp"

car::car(){
	int carID;
	string interval;
	string direction;
}
